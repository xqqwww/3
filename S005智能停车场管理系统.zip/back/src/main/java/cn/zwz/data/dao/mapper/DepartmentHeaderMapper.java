package cn.zwz.data.dao.mapper;

import cn.zwz.data.entity.DepartmentHeader;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @author 郑为中
 * CSDN: Designer 小郑
 */
public interface DepartmentHeaderMapper extends BaseMapper<DepartmentHeader> {
}
