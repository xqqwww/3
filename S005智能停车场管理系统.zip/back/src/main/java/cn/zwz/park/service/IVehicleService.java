package cn.zwz.park.service;

import com.baomidou.mybatisplus.extension.service.IService;
import cn.zwz.park.entity.Vehicle;

/**
 * 车辆 服务层接口
 * @author 郑为中
 */
public interface IVehicleService extends IService<Vehicle> {

}