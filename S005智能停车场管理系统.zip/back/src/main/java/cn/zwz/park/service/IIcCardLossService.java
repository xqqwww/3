package cn.zwz.park.service;

import com.baomidou.mybatisplus.extension.service.IService;
import cn.zwz.park.entity.IcCardLoss;

/**
 * IC卡挂失 服务层接口
 * @author 郑为中
 */
public interface IIcCardLossService extends IService<IcCardLoss> {

}