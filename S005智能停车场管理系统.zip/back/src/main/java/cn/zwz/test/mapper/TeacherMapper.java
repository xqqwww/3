package cn.zwz.test.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import cn.zwz.test.entity.Teacher;

import java.util.List;

/**
 * @author 郑为中
 * CSDN: Designer 小郑
 */
public interface TeacherMapper extends BaseMapper<Teacher> {

}